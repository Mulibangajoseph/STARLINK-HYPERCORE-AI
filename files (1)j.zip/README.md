# STARLINK HYPERCORE FINANCE: installable app (PWA) with Firebase (free Spark plan)

## Set up Firebase
1. console.firebase.google.com > create a project (no billing needed) > add a **Web app** > copy its config.
2. Paste the values into `firebase-config.js`. Never paste service-account or admin keys anywhere.
3. Build > Authentication > Sign-in method > enable **Email/Password**. Edit the verification and password-reset email templates.
4. Authentication > Settings > Authorized domains: keep only your real domains.
5. Build > Firestore Database > create database (production mode). Then publish `firestore.rules` (step 7).

## Run and deploy
6. Test locally (modules and service workers need http, not file://): `npx serve .` and open the printed address.
7. Deploy free over HTTPS: `npm i -g firebase-tools`, `firebase login`, `firebase init hosting` (public folder `.`, single-page app: No; do not overwrite files), then
   `firebase deploy --only hosting,firestore:rules`.

## Install on Android
Open your https address in Chrome on the phone. Use the in-app **Install app** button, or the Chrome menu > **Install app** / **Add to Home Screen**.
It opens full-screen with the Hypercore icon and splash. Desktop Chrome and Edge show an install icon in the address bar.

## Updating
After changing any file, change `V = 'shf-v1'` in `sw.js` (for example to `shf-v2`) so users get the new version.

## Behaviour
Until step 2 is done the page says "Firebase is not configured yet". Sign-up sends a verification email, the dashboard stays locked until verified,
and balances are demo ledger records saved in Firestore under each user's own account. No real money moves.
